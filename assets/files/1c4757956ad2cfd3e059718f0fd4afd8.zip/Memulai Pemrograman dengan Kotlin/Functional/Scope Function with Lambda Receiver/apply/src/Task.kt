fun main() {
    val message = StringBuilder().apply {
        append("Hello ")
        append("Kotlin! ")
        append("my name is lukman!")
    }

    println(message.toString())
}
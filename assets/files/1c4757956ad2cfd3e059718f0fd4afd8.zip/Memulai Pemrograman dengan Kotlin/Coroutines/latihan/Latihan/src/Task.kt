import kotlinx.coroutines.*

// TODO 1
suspend fun sum(valueA: Int, valueB: Int): Int {
    delay(3000)
    return valueA + valueB
}


// TODO 2
suspend fun multiple(valueA: Int, valueB: Int): Int {
    delay(2000)
    return valueA*valueB
}


fun main() = runBlocking {
    val job = launch ( start = CoroutineStart.LAZY ){
        val resultSum = async { sum(10, 10) }
        val resultMultiple = async { multiple(20, 20) }

        println("""
            Result sum: ${resultSum.await()}
            Result multiple: ${resultMultiple.await()}
        """.trimIndent())


    }
    println("Counting...")





    // TODO 3
    job.join()
}
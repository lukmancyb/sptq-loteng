// main function
fun main() {
    val value = 6

    when(value){
        6 -> println("value is enam")
        7 -> println("value is tujuh")
        8 -> println("value is delapan")
    }
}
// main function
fun main() {
    val openOffice = 7
    val now = 8
    val office = if (now > openOffice) "Kantor sudah buka" else "office keluar"

    println(office)
}
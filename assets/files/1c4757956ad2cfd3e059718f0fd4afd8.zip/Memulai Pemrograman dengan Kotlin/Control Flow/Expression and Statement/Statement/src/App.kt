// main function
fun main() {

    val value1 = 10
    val value2 = 10

   var result = sum(value1, value2)
    println(result.toString())
}

fun sum(value1: Int, value2: Int) = value1 + value2